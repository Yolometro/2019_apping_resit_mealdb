package com.example.mealdbapp

import android.app.DownloadManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import kotlinx.android.synthetic.main.activity_main.*
import android.widget.Toast
import android.os.AsyncTask
import android.os.Build
import android.support.annotation.RequiresApi
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL


class MainActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listView = this.findViewById(R.id.listBouffe)

        var bouffeList = arrayOf("Beef", "Chicken", "Dessert", "Lamb", "Miscellaneous", "Pasta",
                "Pork", "Seafood", "Side", "Starter", "Vegan", "Vegetarian")

        val listItems = arrayOfNulls<String>(bouffeList.size)

        val url = "https://www.themealdb.com/api/json/v1/1/categories.php"

        //val stringRequest = StringRequest(Request.Method.GET, url)

       //val test = URL("https://www.themealdb.com/api/json/v1/1/categories.php").readText()

        for (i in 0 until bouffeList.size)
        {
            val bouffe = bouffeList[i]
            listItems[i] = bouffe
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listItems)
        listView.adapter = adapter
    }
}